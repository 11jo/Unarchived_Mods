PALADINS OF FAERUN KITPACK v4
by Yarpen (yarpen_ave@o2.pl)


1. What is this?
2. Installation
3. Contents
4. New kits
  a) Fighter kits
  b) Paladin kits
  c) Ranger kits
  d) Thief kits
  e) Bard kits
  f) Druid kits
5. About the Divine Remix sphere system
6. Thanks

1. WHAT IS THIS?

This kitpack adds to the game 18 new kits, replacing the old ones. As you can see, they generally come from PnP (especially 2nd edition handbooks and FR Campaign Setting), but all are tweaked and improved by me.

All of these kits can be changed/improved, because the mod is still in progress. If you have any suggestions about the general look of this mod, put them on the TeamBG or Sigil forum.

Another thing: This mod is a part of the Paladins of Faerun mod - a big questpack created by the Sigil modding community (from the Czech Republic). Check it at: http://pof.sigil.cz/en/

2. INSTALLATION

a) Requirements/Compatibility
This mod requires the Divine Remix mod, which you can find at the Gibberlings3 site (www.gibberlings3.net), because it supports the sphere assignment system.

This mod removes all kits from the character creation screen.  So if you want to use other custom kits, you should install them after my kitpack.

b) Instructions
Extract all files from the archive to your BG2 or Tutu directory. Launch setup-PoFKits.exe and agree to the installation of the mod.

If you want to uninstall it, also launch this file and agree option of uninstall this component.

3. CONTENTS

This mod adds 18 new kits, replacing the old ones. There are new kits for every class (except clerics and mages).

4. NEW KITS

a) FIGHTER KITS

MERCENARY: This is a full-round fighter, capable of fighting with melee or ranged weapons. He's well trained in using his racial weapons, but has trouble with other types. Also, he's able to focus himself for a few moments and fight harder than in his normal state. 

Mercenaries can select any alignment with "neutral" in it.

Advantages:
- Gain 1 free proficiency point for his racial melee and ranged weapons. 
- Once per day per 5 levels, he can use the 'Inspiration' ability, which grants him for 30 seconds: +2 to THACO and damage, +1 to saving throws, AC and morale, and 1 additional attack per round.

Disadvantages:
- Can achieve grand mastery only in his racial weapons. In other types he is limited to standard specialisation (2 points).
- Can't use plate mail

STREETFIGHTER: Streetfighters have found a place, and even some small amount of fame, among the shadowy and dangerous regions of the world's great cities. Some leave their homes, putting their skills to the test against dangerous monsters in lost tombs or fighting for sport in front of the nobility, but they always remember the lessons of the streets.

Streetfighters never rest easy. They have seen violence and depravity to rival any dungeon adventurer, and they have survived because they never let their guard down. Rather than leaving a streetfighter suspicious or spent, this experience has forged his mind and body into that of a lean, quick-thinking combatant capable of seizing any advantage in battle.

Advantages:
- Immunity to backstab
- +1 to AC and attack speed factory per 5 levels
- Once per day + once per day per 8 levels he can use Sudden strike ability, which makes all his attacks in next round as backstabs with 2x damage modifier. After 20th level multipler raises to 3x.

Disadvantages:
- Can't use metal armours

KNIGHT: A knight is a proud, skilled melee combatant who fights in the name of honour. A knight relies on more than a sharp sword and a stout suit of armour to defeat his foes. His drive, determination, and fighting spirit allow him to control the battlefield in ways that others cannot match.

Knight can't select chaotic alignments.

Advantages:
- Immunity to fear and morale break
- Twice per day can use the 'Battle shout' ability, which cure all forms of fear (but doesn't protect from later fear attacks) and gives the knight's allies +2 to THACO, damages and morale for the next 3 rounds.
- At 12th level once per day can use the 'Fight to end' ability, which grants all his allies an additional 10 hit points, +2 to AC and saving throws, immunity to fear and morale break for the next 10 rounds. After that they lose the temporary hit points.
 
Disadvantages:
- Is limited to mastery (3 points) in melee weapons
- Can't use ranged weapons
- Can't dual class to thief

b) PALADIN KITS

MILITARIST: The Militarist is a battlefield virtuoso. War is a sacred act, he believes, and a chance for spiritual redemption. By defeating enemies in combat, he pays tribute to his gods and secures his place in the afterlife.

Sphere access:
- None

Advantages:
- +1 to THACO and damage
- Can achieve mastery (3 points) in any weapon
- Once per day per 4 levels can use the 'Smite infidels' ability, which grants him in the next round +4 to THACO and damage bonus.

Disadvantages:
- Can't cast spells
- Can't turn undead

ZEALOT: Like other paladins, the devoutly religious Zealots function as soldiers of their church. But Zealots are far more militant, considering devotees of "false" religions as the epitome of evil. Additionally, Zealots follow an unusually strict ethos that includes vows of poverty and chastity.

Because he has a more restrictive code, he can choose only the lawful neutral alignment. Also by his lack of social skills, he has lower charisma requirements.

Sphere access:
- Major: all, combat, law, protection, war and divination

Advantages:
- Additional +1 to saving throws
- Once per day can cast 'Armour of faith'
- Gains improved spell progression (can cast 5 spells of 1st and 2nd levels, and 4 spells of 3rd and 4th levels)

Disadvantages:
- Can't use the 'lay on hands' ability
- -1 penalty to reputation at start

MEDICIAN: On the front lines of battle against evil, injury is inevitable. Where the carnage is at its worst, the Medician can be found keeping his allies alive and tending to the fallen. For a Medician, the goal is not to kill the enemy but to make sure the enemy does not kill his allies.

Spheres access:
- Major: healing, protection, divination and necromancy

Advantages:
- Immunity to diseases and poison
- Gains an additional lay on hands ability every 6 levels
- At 1st level can once per day cast Sanctuary
- At 8th level can once per day cast Cure diseases
- At 12th level can once per day cast Mass heal
- At 17th level can once per day cast Raise dead

Disadvantages:
- Can achieve specialisation (2 points) only in dagger, staff, club, mace, short sword, crossbow, sling and dart.
- -2 penalty to damage

c) RANGER KITS

SCOUT: Any force on the move, whether it's an army or an adventuring group needs information about what's ahead and what's behind and, more important, time to prepare for battle. A scout can navigate difficult terrain at good speed, and he specializes in seeing his foe before the opponent ever detects his presence. In a dungeon or in the wild, a scout is seen only when he wants to be.

Sphere access:
- None

Advantages:
- Gains +20% bonus to hide in shadows and silent walking
- +3 to sight range bonus
- At 5th level gains +1 to movement speed. Gains next +1 at 11th level.
- Once per day can use 'Skirmish' ability, which grants him +1 (and an additional +1 per 5 levels - max +5 at 20th level) bonus to THACO, movement speed and AC for the next 4 rounds.
- At 16th level can once per day cast on himself Freedom of movement.

Disadvantages:
- Can't use metal weapons and armour
- Can't cast standard druidic spells
- Can't dual class into cleric

SEEKER: This ranger has a better connection with the spirit of the environment than anyone else. Nature grants him many powers, wisdom and abilities, which can be helpful in the fight against enemies.

The Seeker can choose from any non-evil alignment, but he still can lose his title (becoming a "fallen ranger").

Sphere access:
- Minor: all, animal, healing, plant, divination, protection and weather

Advantages:
- +10 to lore at start
- Gain bonus spells from 1-4 levels
- Can use items limited only to druids
- At 7th level can once per day shape change into a wolf

Disadvantages:
- Can achieve specialisation only in weapons limited to druids
- Does not get the free 2 points in two-weapons fighting style
- Can't use metal armour

TEMPEST: The Tempest is the point of calm within a whirling barrier of deadly weapons. Poets use colourful terms such as 'dancer' to describe the movements of the Tempest and his two weapons, but mastery of this fighting style is not about dancing. Nor is it about impressing anyone - least of all poets. The Tempest focuses on learning the ultimate secrets of two-weapon fighting for a single purpose - the destruction of his enemies.

Sphere access:
- Minor: all, animal, healing, plant, and weather

Advantages:
- Can achieve mastery in any melee weapon
- Ambidexterity: Tempest do not get the standard -2 Thac0 penalty for off-hand weapons
- Once per day per 5 levels (starting at 5th) can use the 'Parry' ability, which grants him +2 to AC and one hit deflection possibility per 5 levels (starting at 5th level with one deflection) for the next 5 rounds.
- Once per day per 5 levels (starting at 5th) can use the 'Tempest' ability, which grants him in the next 5 rounds one additional attack per 5 levels (starting at 5th level with one additional attack) but also gives a -2 penalty to THACO. 

Disadvantages:
- Is limited to proficiency in ranged weapons
- Can't use the hide in shadows skill
- Can't wear plate armour
- Can't use Charm animals

d) THIEF KITS

GUILD THIEF: Guild thieves are thieves who operate in urban areas as part of an organized thieves' guild. They control and manipulate almost all the crime in their home cities. Guild thieves generally know their minions, their co-workers, and their superior. This web of secrecy preserves the organization, because any that are captured can only sell out a few others.

The Guild thief is a specialist in non-combat thief talents like a trap finding or hiding in shadows. It makes him an excellent burglar. But he's a thief - not a murderer, and is not able to backstab.

Advantages:
- Starts with +5% bonus to all thief skills
- Gains +5% to open locks and detect traps per 2 levels (after 19th, per 3 levels)

Disadvantages:
- Can't backstab

ARCANE TRICKSTER: Arcane Tricksters combine their knowledge of spells with a taste of intrigue, larceny, or just plain mischief. They are among the most adaptable of adventurers.

Advantages:
- Once per day at levels divisible by 5 (1,5,10,15,20, etc.) can cast Reflected image, Luck and Non-detection. These spells have a casting time of 1 and duration of 1 round per level.
- At 12th level can once per day cast Shadow doors
- At 17th level can once per day cast Mislead

Disadvantages:
- Has a limited backstab multiplier. 1-8: 1x, 9-16: 2x, 17+: 3x.
- Gains only 15% of thief skills

THUG: The Thug is the most violent sort of thief. Assassins are killers, certainly, but they depend on refinement and subtlety. Bounty hunters also are willing to use violence, but are relatively restrained as well. Thugs depend only on their bloodlust and brutality.

Cannot choose any good or lawful alignment.

Advantages:
- +2 to melee damage bonus
- +5% to pickpocket and hide in shadows
- Can achieve specialisation in dagger, club, short sword, long sword, and can put 3 points in two weapons style
- Once per day per 3 levels can use 'Bull rush' ability, which grants him in the next round +1 to damage per 3 levels. Also any hit has a 25% chance to stun the enemy (save vs. wands negates). But the stun effect doesn't work on creatures which have more than 90 hit points.

Disadvantages:
- Gains only 20% thief skills per level
- Gains only 1 lore point per level
- Gains set traps at half the rate of a normal thief
- -3 penalty to intelligence and charisma

e) BARD KITS

SPELLSINGER: Spellsingers are rare practitioners of an ancient Elven bardic tradition. Like bards, spellsingers work magic with song and poetics, but, whereas bards draw on the Weave through singing and poetry, spellsingers are truly part of the Weave. As such, spellsingers can work magic through music with greater effect and flexibility than other bards.

They have an innate talent for spell casting, and minor immunity to magic, but are more vulnerable to deadly spells attacks.

Advantages:
- +1 to saving throws vs. spells and wands
- Gain 1 bonus spell per level
- Spellsong: This song makes the bard's companions more protected against enemy magic. But also there's a 5% chance to forget one remembered spell from daily spells.
1st level: +1 to saving throw vs. spells
15th level: +2 to saving throw vs. spells, +5% immunity to magic
20th level: +4 to saving throw vs. spells, +15% immunity to magic

Disadvantages:
- Can't use standard bardsong
- -2 to saving throw vs. death
- Gains only 1/4 of pickpocket skill
- Gains only 5 points of lore per level

BEGUILER: Beguilers see lying and manipulation as tools. Just as a hammer can be used to build a house or crack a skull, deceit and the ability to control others can be used for good or ill. A lie whispered in the right ear can ruin lives, but a dishonest smile and honeyed words can open doors, turn foes into friends, and even end wars.

Beguilers have reputations as rakes, thieves, spies and puppet masters, but they can also be diplomats, peacemakers, or heroic leaders who give hope in desperate situations.

Advantages:
- Immunity to charm and domination
- Starts with +10% pickpocket bonus
- Beguiler song: this bardsong charms enemies who fail their saving throw vs. spells. At 1st level the save has a +3 modifier, at 15th level this is reduced to 0, and at 20th to -2.
- Once per day per 5 levels (starting at 5) can use the 'Charming gaze' ability, which charms the selected creature for 5 rounds (but the enemy can make a saving throw with a -2 penalty.). If he fails his save, he also gains a -2 to saving throw and -5% to magic immunity penalties for 10 rounds.

Disadvantages:
- Gains only 3 lore points per level
- Can't use standard bardsong

DERVISH: Wild, exotic, and as dangerous as his whirling blades, the dervish epitomizes speed, quickness and abandon. Her motions appear to be as random as they are graceful, but the steps of her lethal dance play out according to their own rhythm.

Advantages:
- Can achieve specialisation (2 points) in any 1-handed sword
- Sword dance: this bardsong deals damages to enemies around of Dervish, got chance for blind them and give small bonus to AC and movement speed of bard.
1st level: deals 1D4 damages, 50% chance for blind (save vs. wands negate), +1 to AC and movement speed for Dervish
15th level: deals 1D6 damages, 75% chance for blind (save vs. wands negate), +2 to AC and movement speed for Dervish
20th level: deals 1D8 damages, blind (save vs. wands negate), +3 to AC and movement speed for Dervish

Disadvantages:
- -2 penalty to Thac0 and damage when use ranged weapons
- Can't use standard bardsong
- Can't cast spells

f) DRUID KITS

WEATHER ENCHANTER: This wandering druid is a specialist in enchanting weather. By his spells and abilities, he can summon lighting and ice swarms. Also he can protect others from deadly nature powers.

Sphere access:
- Major: all, animal, elemental (all), healing, plant, sun and weather

Advantages:
- Once per day per 4 levels can use the 'Storm shield' spell, which grants one person immunity to fire, cold and lighting for 8 rounds.
- Once per day per 7 levels (starting at 7th level.) can cast 'Call lightning' and 'Ice storm'

Disadvantages:
- Can't shape change

HIVEMASTER: The Hivemaster druid lives to foster insectoid and arachnid life wherever it exists. Hivemasters appear somewhat enigmatic. Many attempt to instill insectoid virtues in their followers, such as patience, hard work, and close cooperation. A Hivemaster's grove usually centres on the dwelling place of the creature for which the druid has the greatest affinity - a forest covered with spider webs, a field with beehives, etc.

Sphere access:
- Major: all, animal (only insect-based), elemental (all), healing, plant, sun and weather
- Additional mage spells: Web, Spider spawn, Carrion summon

Advantages:
- +4 to saving throws vs. poison
- Immunity to web and insect summoning spells
- At 7th level can once per day shape change into a giant spider
- At 15th level his connection with insects is rising. He gains infravision (regardless of race) and immunity to poison and hold.

Disadvantages:
- Loses all standard druid powers (like normal shape changing and immunities)
- -2 to charisma penalty

BLIGHTER: When a druid turns away from the land, the land turns away from her. Some ex-druids make peace with this change, others seek to restore the bond. A few however, actually embrace their disconnection from nature and become forces of destruction. These few, called blighters, leave their mark wherever they tread.

Sphere access:
- Major: all, necromancy, elemental (all), healing, sun and weather

Advantages:
- Once per day per 4 levels (starting at 5th level) can use 'Contagion touch'. After using that ability, the next touch attack will inflict disease on the enemy. Victim will lose 2 points of strength, constitution and charisma, inflict 10 damage and slow him for next 10 rounds if he fails a saving throw vs. death without a modifier. It's a magic disease which can't be cured by the 'Cure disease' spell.
- At 15th level he changes into an undead creature. Gains immunity to mind-affecting spells, fear and cold. Also, his constitution is changed to 10, but he gains +20 hit points.

Disadvantages:
- Loses all standard druid powers (like normal shape changing and immunities vs. elementals)
- -2 penalty to constitution

5. NOTE ABOUT THE DIVINE REMIX SPHERE SYSTEM
(This material comes from the Gibberlings 3 page: http://www.gibberlings3.net/cleric/)

SPELLS AND SPHERES:

The most notable change to the spell system is the proper implementation of spheres. Like arcane magic and its school system, divine magic can be broken into spheres such as animal, necromancy, protection, etc. The spells available to a divine caster are limited to spheres related to their deity's portfolio. There are three levels of sphere access: 

> Major - character can cast all spells in this sphere 

> Minor - character can cast spells up to and including level three in this sphere 

> None - character can not cast spells in this sphere 

The different spell selections available to a character can vary, sometimes significantly, between classes and even within kits of a class. The spells available to the characters reflect their beliefs, and as such, one spellbook for all no longer makes sense. Sphere restrictions are now included in kit descriptions. Under the implementation of spheres, spells that had previously been druid-only are now accessible to some specialty priests and in some cases (Dolorous Decay) available to trueclass clerics as well. New divine spells are included. If a spell belongs to multiple spheres, access to any of the spell's spheres will grant a character access to the spell. Access to all spheres is not required.

CLERICS:

Trueclass clerics have major access to the spheres of all, charm, combat, creation, divination, guardian, healing, necromantic, protection, and summoning and minor access to the spheres of elemental (earth) and elemental (water).

DRUIDS:

Druids (and their kits, mod or otherwise) have been moved to a druid-appropriate spell sphere selection of major access to all, animal, elemental (all), healing, plant, sun and weather.

PALADINS:

Paladins (and their kits, mod or otherwise) have been moved to a paladin-appropriate spell sphere selection of major access to the spheres of combat, divination, healing and protection.

RANGERS:

Rangers (and their kits, mod or otherwise) have been moved to a ranger-appropriate spell sphere selection of major access to all, animal, healing, plant, and weather.

6. THANKS FOR...
 * All modding communities, modders, translators and players - who still want to improve, and most important, love this game!
 * Coincidence and Shaggie - both teached me everything about modding.
 * Miloch - helped with my weak english, and with some errors :) 
 * Albatros, Folmi, Horus, Grzebul, Sorrow, Orzecho, Kermitt, Leon, Vil, Dun Dare, Alatariel, Aleksandrus and maaany other people from Polish forums!
 * Igi, MajorTomSawyer, Seifer, Andyr, CamDawg, Badgert and some other people from English forums :)
 * Mroczna Koza!


