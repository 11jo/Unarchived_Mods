
==================================================================================
Pack Name: "Disc 255 Fix V2.0"
==================================================================================
Creator Name: josh_clue  
Creator Email: josh_clue@hotmail.com
==================================================================================
Compatible Games:
----------------------------------------------------------------------------------

 [ ] Baldur's Gate
 [ ] Baldur's Gate: Tales of the Sword Coast
 [x] BG1TuTu

 [ ] Baldur's Gate II: Shadows of Amn
 [ ] Baldur's Gate II: Throne of Bhaal

 [ ] Icewind Dale
 [ ] Icewind Dale: Heart of Winter
 [ ] Icewind Dale: Heart of Winter with Trials of the Luremaster

 [ ] Planescape: Torment

==================================================================================
ABOUT: "Disc 255 Fix V2.0"
----------------------------------------------------------------------------------

This  is  a  fix for the people getting the  "Insert Disc 255"  error  in  BG1TuTu
whenever  a movie in a particular area needs to be played. I have learned that  it 
could be caused by any of the following:

1. a full install was NOT done and the movies are not in the BG1 directory
2. a full install WAS done, however, the CDs used during the installation are old
   and scratched, and the BIF files containing the movies cannot be read properly
 
This  differs from Version 1.0 which contained script files (.BCS files) that were 
simply  copied  over onto the Baldur's Gate Override  directory.  Version 2.0  now 
works around this to allow compatibility with other WeiDU mods by setting off  the
triggers that started the movies and by patching the otherwise complicated scripts
that involved more than just playing movie files, AR1900 and AR4800, for example.
There are, however, movies that play automatically without any script prompting it 
to play, the starting movie with the Black Isle logo, for example, and you will have
to set the "Disable Movies=1" in the baldur.ini file if you still get errors for 
these particular movies.   

==================================================================================
INSTALLATION:
----------------------------------------------------------------------------------

This is for BG1TuTu ONLY!

The Disc 255 Fix v2.0 will install correctly over (or without) any 
other WeiDU mods.

Unzip the main ZIP file into your BG main directory. This is normally:
        C:\Program Files\Black Isle\Baldur's Gate\

Run (click on) "Setup-Disc255.exe" 

Monks  will appear in Candlekeep, outside the inn [1205.560], and Beregost, beside
the  obelisk in the middle of town [1900.2475], who can readily disable or  enable
the fix.   

==================================================================================
THANKS:
----------------------------------------------------------------------------------

* Forgotten Wars Studios Forums
* Revasser, for pointing the problem out

==================================================================================
VERSION HISTORY:
----------------------------------------------------------------------------------
Version 1.0 
   * initial public release
   * presented compatibility issues with other WeiDU mods

Version 2.0
   * WeiDU v185 used
   
==================================================================================
KNOWN BUGS:
----------------------------------------------------------------------------------

   * none yet 

==================================================================================
LINKS:
----------------------------------------------------------------------------------
http://www.angelfire.com/rpg2/azenmod	(home of Azengaard Tactical Encounter)

http://www.magma.ca/~carl2/arundor/abode/bg_misc.html
					(for The Vault Item Pack and Mini MOD)

http://www.weidu.org			(home of the WeiDu utility)

http://www.idi.ntnu.no/~joh/ni/index.html
					(home of the Near Infinity utility)

http://forums.fwstudios.net/ 		(Forgotten Wars Studios Forums => WeiDu Forums)

http://www.sorcerers.net/Games/BG2/index_teambg.php
			 		(game customizing programs/editors)

http://chosenofmystra.net/mods/dsotsc/index.htm
			 		(Dark Side of the Sword Coast, WeiDU Version)

http://www.pocketplane.net/tutu		(home of BG1Tutu)


