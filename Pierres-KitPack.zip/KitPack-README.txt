I'm Pierre, and this is my Kit pack.  
You must have Kit Editor found at http://www.teambg.com/ to load these kits.  Unzip into any directory, and then load up Kit Editor.  YOU WANT TO BACK UP ALL YOUR OVERRIDE FILES THAT KIT EDITOR WILL USE (the prog will tell you which ones).  You then want to use Kit Editor to Import whichever of my kits you want to use, then save them in the override folder.
These kits are basic, there is nothing fancy or special about them.  I just thought it'd be cool to have some different options so that my characters could be better defined in the class section.

DISCLAIMER:
I am not responsible for any bugs/problems these kits may have or how they may effect your game.  Use These AT YOUR OWN RISK!!!!!!!
Think My Kits suck?  Make your own!

E-mail me any bugs you may experience or your thoughts on my kits.
Or, if you have any requests for new kits i'll see what i can do...
E-mail Addy:  CutthroatPirate@aol.com


THUG:  Combatant Thief. The Thug uses his brute force to take what he wants when he wants.  He is a vicious ruffian and murderer.
Advantages:  Some of Monk's special abilities have been added                               
+1 Damage Bonus every 10 Levels 
May achieve grand mastery of the Club
Disadvantages:                                                                        
Can Not set traps (DO NOT WASTE Thief skill points in this area)         
Some of Thief special abilities have been removed (such as set traps)  
Can Not become proficient in ranged weapons

MERCENARY:  Professional Soldier for Hire.  The Mercenary is a rogue soldier, well rounded in all forms of combat.  He is willing to serve in any guerilla organization, or for any private citizen if the price is right.
Advantages:
GA set normal traps every 10 levels
TOB abilities have been extended.
May go into Berserker state once per day
-1 AC
Movement Modifier 1, at level 10
Disadvantages:
May not wear Plate Armor
Can put only 4 proficiency points in all melee weapons
Can put only 2 proficiency points in all ranged weapons
Some fighter abilities have been removed

CUTTHROAT:  This is the most sly and ruthless thief.  He is the master of the Dagger, and shortsword, and his backstabbing abilities are only matched by that of the assassin.  As quick and cunning as an assassin, but very restricted in his choice of weaponry.  As ruthless and murderous as a thug, but prefers not to use brute force, or engage in face to face confrontation.  The Cutthroat will take out an enemy when he is least expected.
Advantages:
+1 Damage
May put 4 proficiency points into the dagger
May put 3 proficiency points into the short sword
Disadvantages:
May set snares but not use TOB traps
Max strength 16
Max intelligence 17
May not put proficiency points into ranged weapons
