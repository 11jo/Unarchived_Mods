Ethereal Blademaster Ranger Kit
Baldur's Gate II: Throne of Bhaal REQUIRED

This is a custom kit designed by Medivh of War Hawk Entertainment for Baldur's Gate II Ranger Class, please note that this Kit REQUIRES Throne of Bhaal Expansion if you plan on advancing beyond Level 16 Due to Abilities or other files needed for the class that cannot be provided here.

KNOWN ISSUE:
	Balancing:
		Please note that this is the First(Beta) Version of this class, it is fully working as long as ALL files in the zip are extracted to your BGII Override folder. But also keep in mind that as this is the Beta, this class has not been fully and properly balanced to resemble the other kits and classes. This class is most likley more powerful than many kits in BG2 until I release Version 2.

All Files contained withing the ZIP file for the Ethereal Blademaster are Copyright(c) War Hawk Entertainment or other respective owners, mainly TeamBG and Bioware due to the utilites and files required. These files are NOT to be modified and redistributed without consent of War Hawk Entertainment!

Visit our web page at:
www.lunarpages.com/medivh/

War Hawk Entertainment
Medivh