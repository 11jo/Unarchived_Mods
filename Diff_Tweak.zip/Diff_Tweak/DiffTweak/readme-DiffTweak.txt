Difficulty and Tweaks mod ver 6 (previously Mix Mod)

        
ABOUT

The mod should work with any IE game

This mod changes the difficulty of the game by boosting the attributes of your enemies, you can decide how much each stat is raised.

It also includes a few tweak, for example increasing item stacks by a factor chosen by the player.

Up to version five this mod was called Mix Mod, in version 6 I excluded some modules incorporated in other mods, and since this mod became focused on difficulty and tweaks the name was accordingly changed.

INSTALLATION

Unpack the mod to the game's main directory, unless you are using Beamdog's version of BG:EE in that case unpack to Baldur's Gate Enhanced Edition\Data\00766\ (Steam version uses sane file system, so you do not have to worry about that)

The installation program should run automatically after unpacking, in case it doesn't run Install_DiffTweak.bat and follow the instructions. In case of BG:EE you will be able to choose your language.

If you want to change the options later run setup-DiffTweak.exe, I recommend installing this mod after all the other so that you can do it easily.

If you have it installed please uninstall completely all previous versions of Mix Mod. Sorry for inconvenience.

Stacking components will detect components of similar nature from other mods, while they'll still prompt you to install in fact they won't be installed in such a case, instead a message will be displayed on screen stating with which component from which mod is a given component incompatible with. So please pay attention to on-screen messages.
NOTE TO MODDERS

All Mix Mod components will create a dummy file allowing their detection (see .tp2). Components with multiple subcomponents will create the same file regardless of subcomponent chosen.
Also every one should feel free to reuse/modify all of this mod without asking my permission.

GAME COMPATIBILITY

The mod should work with any IE game, unless the components says it's for BG2/EE/TUTU only.

Please note that not all IE games got the same amount of testing with this mod. Especially PST is little tested.

BG:EE is supported for the first time, while I do not expect any problems, they are possible

COMPONENTS

1. Increased Ammo Stacks - All IE Games.

   This one was designed for those for whom unlimited stacks seems too much of a "cheat". You can increase the stacks by 50, 100, 200, 300, 400, 500, 750% of the original game value.
   You can also Decrease Ammo stacks by 50% (so all hard-core BG1 fans can have their stacks in BG2 effectively as in BG1)
   
2. Increased Gem and Jewellery Stacking - All IE Games.

   This one was designed for those for whom unlimited stacks seems too much of a "cheat". You can increase the stacks by 50, 100, 200, 300, 400, 500, 750% of the original game value.
   
3. Increased Potion Stacking - All IE Games.

   This one was designed for those for whom unlimited stacks seems too much of a "cheat". You can increase the stacks by 50, 100, 200, 300, 400, 500, 750% of the original game value.
   
4. Increased Scroll Stacking - All IE Games.

   This one was designed for those for whom unlimited stacks seems too much of a "cheat". You can increase the stacks by 50, 100, 200, 300, 400, 500, 750% of the original game value.
   
5. Tougher Enemies - All IE Games

   This component is meant to be an alternative to things like Tactics mod. It will boost the abilities of all your enemies (note that all player controlled/allied creatures should be excluded, though strange coding by game devs in few places may give these bonuses to summons etc., but this'll be extremely rare)

   Enemy creatures will get bonuses to:

   AC
   THAC0
   SAVE THROWS
   
   This component has several subcomponents, so you'll be able to choose how big the bonuses are (ranging from 1 to 6), you can freely change those mid-game with no problems
    
   
   NOTE ON IWD2: IWD2 difficulty slider increases not only damage dealt by enemies but also their save throws and to hit. Thus this component will only give 50% of normal boost for IWD2 enemies.

6. Increased Enemies' HP - All IE Games.

   This will boost only HP (but summons like previously will be excluded) ranging from 25% added to HP to 300%
 
7. True Grand Mastery - Baldur's Gate 2/Tutu/BGEE

   Similar to the one from Ease-of-Use but this one allows you to choose if you want the extra half-attack and the to-hit and damage bonus you had in BG1 and IWD or you can leave out the extra attack for balance purposes.
   
 
8. Helmets for Shapeshifters Bug Fix - Baldur's Gate 2/Tutu/BGEE

    Kensai and mages cannot wear armour and thus they cannot wear helmets. Shapeshifters cannot wear armour but can wear helmets. If this bothers you, then install this one.


VERSION HISTORY


V6 � Changed name to Difficulty and Tweak mod	
   - Added BG:EE compatibility
   - Cleaned and fixed IWD2 code
   - Reworked and separated HP boost from other stats
   - Removed shapeshifting rebalancing, it is now a part of Refinements mod.
   - Removed �remove startup movies�, little benefit and the code was difficult to maintain	
   - Removed  P&P Style Protection Items � it's now properly supported in G3 tweak packs
   - Upgraded Weidu used
	

V5 - Complete redesign of the mod
   - Made improvement to code
   - Increased compatibility with other mods
   - Added tougher enemies component
   - Tougher enemies & increased enemy HP able to exclude summons and their like
   - Merged Movie off components
   - Added P&P Style Protection Items

V4 - Added component: 12

V3 - Added components: 8, 9, 10,11
   - Fixed a small bug with 50% increase of potion/jewellery/scroll stacking.
   - Some more tp2 code improvements
   - Added 750% option to components 1-4
   - Added 150% option to component 5

V2 - Improved tp2 to avoid install problems on some builds, fixed bugs in potion/jewellery/scroll stacking & True Grand Mastery components.

V1 - Initial release.

Pre V1 - IE Games Harder Mod - then made part of this one.


CREDITS
This mod includes modified work of G. Maestro, Littiz, the_bigg, CamDawg, Idobek.
Also I'd like to thank Simding0, Rastor, Andyr and CamDawg.
Bursk for bug-spotting.
Aigleborgne for Helmets for Shapeshifters idea.


CONTACT

If you have any comments come to the Borsook's Chambers:

http://forums.rpgdungeon.net/index.php/board,41.0.html

or send an email to

nikolaj@poczta.onet.pl
