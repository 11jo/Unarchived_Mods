@echo off
echo If you're using Beamdog's edition make sure you've extracted the mod to Baldur's Gate Enhanced Edition\Data\00766\
echo This is not an issue for Steam version
echo
echo Choose your language:
echo 1. CZ
echo 2. DE
echo 3. US
echo 4. ES
echo 5. FR
echo 6. IT
echo 7. PL
echo 8. BR
echo 9. TR
Choice /C 123456789 /M "Choose your language"
If Errorlevel 9 Goto 9
If Errorlevel 8 Goto 8
If Errorlevel 7 Goto 7
If Errorlevel 6 Goto 6
If Errorlevel 5 Goto 5
If Errorlevel 4 Goto 4
If Errorlevel 3 Goto 3
If Errorlevel 2 Goto 2
If Errorlevel 1 Goto 1

:1
mklink /H dialog.tlk lang\cs_CZ\dialog.tlk
goto end

:2
mklink /H dialog.tlk lang\de_DE\dialog.tlk
mklink /H dialogF.tlk lang\de_DE\dialogF.tlk

goto end

:3
mklink /H dialog.tlk lang\en_US\dialog.tlk
goto end

:4
mklink /H dialog.tlk lang\es_ES\dialog.tlk
mklink /H dialogF.tlk lang\es_ES\dialogF.tlk
goto end

:5
mklink /H dialog.tlk lang\fr_FR\dialog.tlk
mklink /H dialogF.tlk lang\fr_FR\dialogF.tlk
goto end

:6
mklink /H dialog.tlk lang\it_IT\dialog.tlk
mklink /H dialogF.tlk lang\it_IT\dialogF.tlk
goto end

:7
mklink /H dialog.tlk lang\pl_PL\dialog.tlk
mklink /H dialogF.tlk lang\pl_PL\dialogF.tlk
goto end

:8
mklink /H dialog.tlk lang\pt_BR\dialog.tlk
mklink /H dialogF.tlk lang\pt_BR\dialogF.tlk
goto end

:9
mklink /H dialog.tlk lang\tr_TR\dialog.tlk
mklink /H dialogF.tlk lang\tr_TR\dialogF.tlk
goto end

:end
mkdir override
setup-DiffTweak.exe
