@echo off
echo
echo 1. Baldur's Gate Enhanced Edition
echo 2. Classic Infinity Engine (Bg1/2/Tutu/PsT/IWD/IWD2)

Choice /C 12 /M "Which version are you installing?"
If Errorlevel 2 Goto 2
If Errorlevel 1 Goto 1

Goto End

:1
Echo You chose Baldur's Gate Enhanced Edition
call "BGee_DiffTweak.bat"
Goto End1

:2
Echo You chose Classic Infinity Engine
setup-DiffTweak.exe
Goto End

:End
pause