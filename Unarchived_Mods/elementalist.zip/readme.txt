you need teambgs kit editor to import this kit get from www.teambg.com
this file may not be distributed without my express written consent.
my email jjjj480@hotmail.com

the author is not responsible to any possible damage  to your computer.
no waranty of any kind is given.

remeber to install the iap otherwise the druid wont gain his resistances


written by Daemon