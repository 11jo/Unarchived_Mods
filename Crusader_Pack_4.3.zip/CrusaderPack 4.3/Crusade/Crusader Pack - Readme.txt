Crusader Pack
---------------------------------------------------------------
Author: Raumoheru & Aion/St.Aion (after v2)
Contact: raumoheru@hotmail.com or st.aionmodding@yahoo.com
Website: http://volcanoproductions.blogspot.com
Forum: http://z7.invisionfree.com/aionism
---------------------------------------------------------------
This mod adds three new kits and three new items to Baldur�s Gate II. ToB is required, as some ToB store files are used.

---------------------------------------------------------------
The kits:
---------------------------------------------------------------

Champions of Torm are mighty warriors who dedicate themselves to Torm's cause, defending holy ground, destroying enemies of the church, and slaying mythical beast
Advantages:
- An extra lay on hands per day every 4 levels
- +3 to hit/damage for 30 seconds once per day
- +3 to all saving throws
Disadvantages:
- May not use ranged weapons


Energist: Energist dedicate themselves to the study of spiritual energy, how it flows through our bodies, and how to manipulate it. They are very competitive, always testing to see just how far the can push their bodies and minds.
Advantages:
- Able to use Innate Techniques
- +2 to AC every 10 levels
Disadvantages:
- May not wear armor
- May not use missile weapons
- May not Duel Class
- Does not gain High Level Abilities
- Only 3 proficiency slots may be chosen


Adventurer: A jack-of-all-trades, not so much a thief as a character who takes advantage of the general thieving skills on adventures. An Adventurer is preferred by many adventuring parties, because he is much less likely than other thieves to betray or steal from his own companions. The successful Adventurer knows the value of trust and cooperation, while many a "street thief" has been raised on duplicity and (sometimes literal) backstabbing. 
Advantages:
- +20% to Open Locks and Find/Remove Traps
- +30 lore
Disadvantages:
- No backstab multiplier

---------------------------------------------------------------
The items:
---------------------------------------------------------------

Items: In order to use these you must use the CLUAConsole command. the names after the dash is the resource name in which to do so.
Carsomyr of the Magi - CarMagi
Magebane - Magebane
Mithril Full Plate +5 � Mithril

Note by Aion:
No longer needed. The items can now be bought at stores in ToB, and they now have a description. The item filenames have changed too, to ensure compatibility with other mods.

---------------------------------------------------------------
Version History:
---------------------------------------------------------------

Version 1:
- Initial release by Raumoheru.

Version 2:
- Fixes by Raumoheru.

Version 3:
-Aion starts to update the mod.
-Switched to WeiDU version 185.
-Made the kits compatible with other mods, such as NPC Kits by Idobek.

Version 4:
-Gave the items descriptions and made them available at ToB stores.
-Updated the readme file.

Version 4.1:
-Updated to WeiDU version 218.
-Updated the readme file.

Version 4.2:
-Updated to Volcano Productions mod.

Version 4.3:
-Updated to WeiDU version 230.