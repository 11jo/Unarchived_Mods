                             Baldur's Gate II
                               Itm Value Tweaks Mod
		  Stephen Mackey <karkadinn@aol.com>


		Table of Contents
		~~~~~~~~~~~~~~~~~

I. 	General Info
II. 	Installation
III.	Known Bugs
V.	Thanks

		Section I. General Info
		~~~~~~~~~~~~~~~~~~~~~~~

This mod tweaks the gold values of various items that seemed like they should have been
worth more (or less) than the original game gave them.  For instance, the Root of the
Problem is a fairly decent magical club, and yet in the original games is worth no gold
whatsoever.
Below you'll find the new values for various items.  In most cases, values were adjusted
upwards, usually from zero, using similar items as a basis for comparison.  In some
cases prices were adjusted back to Baldur's Gate I values for sake of player convenience.
In one case, value was REDUCED to zero to prevent infinite gold scumming from an item that
could be created infinitely.

Arrows: 1 gp
The Root of the Problem: 900 gp
Bolts: 1 gp
History of Shadowdale (BOOK27.ITM): 2 gp
Gesen Bow Shaft: 50 gp
Gesen Bow String: 45 gp
Bullet: 1 gp
Bowstring of Gond: 45 gp
Poisoned Throwing Dagger: 2 gp
Dagger of <CHARNAME>: 300 gp
Dart: 1 gp
Deck of Many Things: 5,000 gp
Mask of King Strohm III: 50 gp
Kuo-Toa Bolt: 3 gp
Book of Infinite Spells: 1,500 gp
Efreeti Bottle: 2,000 gp
Horn of Blasting: 1,000 gp
Horn of Silence: 1,000 gp
Golden Pantaloons: 100 gp
Silver Pantaloons: 80 gp
The Lover's Ring: 10 gp
Shaman's Staff: 85 gp
Harper Pin: 5,000 gp
Planar Stone: 100 gp
Mithril Medallion: 500 gp
Moon Dog Figurine: 2,000 gp
Mantle of Waukeen: 250 gp
Pendant: 1 gp
Light Gem: 100 gp
Mithril Token: 5 gp
Golden Arm and Leg: 500 gp
Golden Torso: 500 gp
Bronze Pantalettes: 60 gp
Jansen Spectroscopes: 250 gp
Jansen Techno-Gloves: 80 gp
Delryn Family Shield: 600 gp
Paralytic Bolt: 3 gp
Cursed Scroll of Ailment: 25 gp
Cursed Scroll of Stupidity: 25 gp
Rogue Stone (SCRL3I.ITM): 1,000 gp
Crom Faeyr Scroll: 200 gp
Sling: 1 gp
Sling +3 (SLNG03.ITM): 1,550 gp
Spear +3, Backbiter: 100 gp
Dart +5 (STARDART.ITM): 0 gp

		Section II. Installation
		~~~~~~~~~~~~~~~~~~~~~~~~

Baldur's Gate II: Shadows of Amn is necessary.  This mod SHOULD work fine with any other
Weidu mod.  If something screwy happens, e-mail me.
Unzip the zip file to your main BG2 folder.  This will create an additional folder,
containing most of the mod's files, as well as stick Setup-ItmValueTweaks.exe and
ItmValueTweaks.tp2 in the main folder.  Doubleclick the exe, then press Y to install.

		Section III. Known Bugs 
		~~~~~~~~~~~~~~~~~~~~~~~

None so far.  Yay.

		Section V. Thanks
		~~~~~~~~~~~~~~~~~

Thanks to Westley Weimer for the Readme style.  I shamelessly copied it. ;)  Also thanks to
him for creating the Weidu program, which is quite a lot of help in mod creation.
And last, BIG thanks to Sqweek, without whom I doubt I would have ever figured out how to do
all this headache-inducing mod-related stuff.