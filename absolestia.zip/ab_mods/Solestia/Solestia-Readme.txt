Solestia an NPC for BGII SOA
Version 1.2

To Install
1) unzip within your BGII directory
2) Run Setup-abSolestia.exe

To Uninstall
1) Run Setup-abSolestia.exe
2) Remove Setup-abSolestia.exe, Setup-abSolestia.tp2, and Solestia directory inside the ab_mods directory.
2a) If you have no other ab_mods installed you may safely remove the ab_mods directory as well.

This mod adds a unique NPC to the gaming experience of BGII Shadows of Amn.
Version 1 was made in a little over 12 hours with a brief break in the middle.

Stats
Name: Solestia De'Luna
Race: Human/Halfling (human animation/paperdoll, halfling race)
Class: Thief - Swashbuckler
Gender: Female
STR: 16
DEX: 17
CON: 12
INT: 13
WIS: 8
CHR: 14
LEVEL: 8
XP: 89000

Solestia is a Thief from Gullykin. She appears human but is actually part halfling. Her armor is a family heirloom and she will not part with it. This serves the purpose of preventing the game from switching her animation to halfling when armor is swapped out. You can find her in the Copper Cornet with her two halfling cousins, Shorty and Slinger. I haven't made real names for them yet, they're just nicknames for now.

Solestia does not yet talk while in the party. There are no sound files at this time.

You have three chances total for Solestia to join you. One at the intial conversation, and two more if you talk to her on some future visits to the Copper Cornet. Each of the rejection options get more insulting as you go. Should you continue to reject her offers to join you she and her cousins will eventually become violent. You get more 500 xp each for killing her cousins and only 100 for her (because she is an npc and they aren't supposed to have xp). You can net some stuff from the cousins as well as from Solestia if you end up killing them. I'll let you find out what... But you can get some better stuff if you let her join...

I know I've left room for banters, interjections, romance etc... but I'm just not sure how to do that at this time.
If anyone would like to add some things perhaps in a crossmod banter type of mod, please let me know and I'll work with you.

Some thoughts on future banters:
Solestia has slipped away from the party. PC finds her. She's been caught shaving her feet. Ensuing discussion paths about what it's like being too tall to blend in with the halflings and that most humans wouldn't know she was part halfling if she could just keep her hairy feet shaved.

Perhaps some Amn based halflings have heard of her and have taken to making fun of her by calling her a Wholeling...

Beyond that I'm open to just about any suggestions...

CHANGES
Version 1.2
Added a time limit for her and her cousins to be out working.
She will complain and eventually leave if you do not return her to the Copper Coronet to meet her cousins.
Added a quest to find a trading partner for her father.
Afterwards she will stay or leave depending upon your choices.

Version 1.1
NOT RELEASED
Added banter with two cousins.
Changed class to straight thief and assigned swashbuckler kit.
Added an inventory container to Solestia to go along with the pre-join banter.
Adjusted readme a bit.

Version 1
Initial release - boring basics to join and kick out