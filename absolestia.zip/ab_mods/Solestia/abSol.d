EXTEND_BOTTOM HAQUAT 0
IF ~IfValidForPartyDialogue("Solestia")
    !Dead("Solestia")
    !StateCheck("Solestia",STATE_SLEEPING)
    Global("ab_solqmerchant","GLOBAL",1)~ THEN REPLY @1130 GOTO oilwater
END

APPEND HAQUAT
IF ~~ THEN BEGIN oilwater
 SAY @1131
 IF ~~ THEN REPLY @1132 GOTO oilwater2
END

IF ~~ THEN BEGIN oilwater2
 SAY @1133
  IF ~~ THEN DO ~SetGlobal("ab_solqmerchant","GLOBAL",2)~ EXIT
END
END

BEGIN abhalf1
IF ~Global("ab_soljoinded","GLOBAL",0)~ THEN BEGIN 1half1
    SAY @1050 //~You need to be talking to Solestia. She's the one in charge...~
    IF ~~ THEN EXIT
END

IF ~Global("ab_halfchain","GLOBAL",1)~ THEN BEGIN 2half1
   SAY @1051 //~She's a thief, a bit flashy, but a thief nonetheless.~
   IF ~~ THEN EXTERN ab_sol 11sol
END

IF ~IfValidForPartyDialogue("Solestia")
    !Dead("Solestia")
    !Global("ab_solmeetcousins","GLOBAL",4)
    !GlobalTimerNotExpired("ab_solqmeetcousins","GLOBAL")~
THEN BEGIN 3half1
 SAY @1107
 IF ~~ THEN REPLY @1108 EXTERN abhalf2 6half2
END

IF ~~ THEN BEGIN 4half1
 SAY @1110
 IF ~~ THEN EXTERN ab_solJ 1
END

IF ~~ THEN BEGIN 5half1
 SAY @1113
 IF ~Global("ab_askmoney","GLOBAL",0)~ THEN REPLY @1114 EXTERN abhalf2 7half2
 IF ~Global("ab_askmerchant","GLOBAL",0)~ THEN REPLY @1115 GOTO 6half1
 IF ~Global("ab_askmerchant","GLOBAL",1)
     Global("ab_askmoney","GLOBAL",1)~ THEN REPLY @1116 DO ~SetGlobal("ab_solqmerchant","GLOBAL",1)~ UNSOLVED_JOURNAL @1119 EXIT
END

IF ~~ THEN BEGIN 6half1
 SAY @1118
 IF ~~ THEN DO ~SetGlobal("ab_askmerchant","GLOBAL",1)~ GOTO 5half1
END

IF ~GlobalGT("ab_solqmerchant","GLOBAL",0)
    GlobalLT("ab_solqmerchant","GLOBAL",3)
    PartyGoldLT(2500)~ THEN BEGIN 7half1a
 SAY @1120
 IF ~Global("ab_solqmerchant","GLOBAL",1)~ THEN REPLY @1121 EXTERN abhalf2 8half2
END

IF ~GlobalGT("ab_solqmerchant","GLOBAL",0)
    GlobalLT("ab_solqmerchant","GLOBAL",3)
    PartyGoldGT(2500)~ THEN BEGIN 7half1
 SAY @1120
 IF ~Global("ab_solqmerchant","GLOBAL",1)~ THEN REPLY @1121 EXTERN abhalf2 8half2
 IF ~Global("ab_solqmerchant","GLOBAL",2)~ THEN REPLY @1122 EXTERN ab_solj 2
END

BEGIN abhalf2
IF ~Global("ab_soljoinded","GLOBAL",0)~ THEN BEGIN 1half2
    SAY @1100 //~Solestia is the one you need to speak with...~
    IF ~~ THEN EXIT
END

IF ~Global("ab_halfchain","GLOBAL",1)~ THEN BEGIN 2half2
   SAY @1101 //~Keep an eye on Solestia. She likes to practice her skills on her friends and family.~
   IF ~~ THEN REPLY @1103 EXTERN abhalf1 2half1
END

IF ~Global("ab_halfchain","GLOBAL",1)~ THEN BEGIN 3half2
   SAY @1104 =@1102 //~Hey, where's that magic bag I found last year in those ruins...~
   IF ~~ THEN EXTERN ab_sol 9sol
END

IF ~~ THEN BEGIN 4half2
 SAY @1105
 IF ~~ THEN EXTERN ab_sol 13sol
END

IF ~~ THEN BEGIN 5half2
 SAY @1106
 IF ~~ THEN EXTERN ab_sol 10sol
END

IF ~~ THEN BEGIN 6half2
 SAY @1109
 IF ~~ THEN EXTERN abhalf1 4half1
END

IF ~~ THEN BEGIN 7half2
 SAY @1117
 IF ~~ THEN DO ~SetGlobal("ab_askmoney","GLOBAL",1)~ EXTERN abhalf1 5half1
END

IF ~~ THEN BEGIN 8half2
 SAY @1123
 IF ~~ THEN EXIT
END

IF ~~ THEN BEGIN 9half2
 SAY @1125
 IF ~~ THEN EXTERN ab_solj 3
END
//Solestia's opening dialog
BEGIN ab_sol

IF ~NumTimesTalkedTo(0)~ THEN BEGIN 1sol
 SAY @1000 //~Hi. I am Solestia. These are my cousins Shorty and Slinger.~
 IF ~~ THEN REPLY @1003 GOTO 1sola
END
IF ~~ THEN BEGIN 1sola
  SAY @1001 //~Are you looking for work? My cousins and I are. How about we look for work together?~
  = @1004 //~I've got a bow, some arrows... All I need is a target...~
  = @1006 //~What do you say?~
 IF ~~ THEN REPLY @1007 GOTO 2sol //~Yes, we may look for work together so long as you do not target my back with your bow and arrows.~
 IF ~~ THEN REPLY @1008 GOTO 3sol //~We both maybe looking for work, but we aren't doing it together.~
END

IF ~~ THEN BEGIN 2sol
 SAY @1009 //~Have no fear! I would never willingly target your back or your front for that matter. Well not with my bow and arrows anyway... *wink*~
 IF ~~ THEN REPLY @1033 GOTO 14sol
END

IF ~~ THEN BEGIN 3sol
 SAY @1010 //~If you should change your mind, I might still be here.~
 IF ~~ THEN DO ~SetGlobal("ab_solreject","GLOBAL",1)~ EXIT
END

IF ~!NumTimesTalkedTo(0)
   Global("ab_solreject","GLOBAL",1)~ THEN BEGIN 4sol
 SAY @1011 //~Change your mind have you?~
 IF ~~ THEN REPLY @1012 GOTO 8sol //~Yes, I have. Come with us.~
 IF ~~ THEN REPLY @1013 DO ~IncrementGlobal("ab_solreject","GLOBAL",1)~ EXIT //~No, I must have mistaken you for some commoner.~
END

IF ~!NumTimesTalkedTo(0)
   Global("ab_solreject","GLOBAL",2)~ THEN BEGIN 5sol
 SAY @1026 //~You've come again. Are we to join forces this time?~
 IF ~~ THEN REPLY @1027 GOTO 8sol //~Why yes! We have a use for you and your bow...~
 IF ~~ THEN REPLY @1028 DO ~IncrementGlobal("ab_solreject","GLOBAL",1)~ EXIT //~Did you guys hear something? I thought I heard a bunch of hot air go by.~
END

IF ~!NumTimesTalkedTo(0)
   Global("ab_solreject","GLOBAL",3)~ THEN BEGIN 6sol
 SAY @1014 //~I'm getting a little tired of you.~
  = @1015 //~If you don't wish for me to join with you then leave me alone.~
  IF ~~ THEN DO ~IncrementGlobal("ab_solreject","GLOBAL",1)~ EXIT
END

IF ~!NumTimesTalkedTo(0)
   Global("ab_solreject","GLOBAL",4)~ THEN BEGIN 7sol
 SAY @1016 //~I told you to leave me alone!~
  = @1017 //~Have at them my cousins!~
  IF ~~ THEN DO ~ActionOverride("Slinger",Enemy())
                 ActionOverride("Shorty",Enemy())
                 Enemy()
                 Attack(LastTalkedToBy(Myself))~ EXIT
END

IF ~~ THEN BEGIN 8sol
 SAY @1002 //~Hey cousins, <CHARNAME> has asked me to join up. I'll be seeing you around.~
  IF ~~ THEN DO ~SetGlobal("ab_halfchain","GLOBAL",1)~ EXTERN abhalf2 2half2
END

IF ~~ THEN BEGIN 9sol
 SAY @1005 //~I've no clue what you're talking about Shorty. I saw you with it yesterday.~
 IF ~~ THEN REPLY @994 EXTERN abhalf2 5half2
 IF ~~ THEN REPLY @995 GOTO 12sol
END

IF ~~ THEN BEGIN 10sol
 SAY @999 // ~Did you check the inn we stayed at last night? You two go look for it. I'll go with <CHARNAME>.~
 IF ~~ THEN DO ~SetGlobal("ab_soljoined","GLOBAL",1)
                SetGlobal("ab_solmeetcousins","GLOBAL",1)
                SetGlobalTimer("ab_solqmeetcousins","GLOBAL",72000)
                ActionOverride("Slinger",EscapeArea())
                ActionOverride("Shorty",EscapeArea())
                JoinParty()~
                UNSOLVED_JOURNAL @1036
                EXIT
END

IF ~~ THEN BEGIN 11sol
 SAY @998 =@997 =@996
 IF ~~ THEN EXTERN abhalf2 3half2
END

IF ~~ THEN BEGIN 12sol
 SAY @993 =@992
 IF ~~ THEN EXTERN abhalf2 4half2
END

IF ~~ THEN BEGIN 13sol
 SAY @991 =@990
 IF ~~ THEN DO ~SetGlobal("ab_soljoined","GLOBAL",1)
                SetGlobal("ab_solmeetcousins","GLOBAL",1)
                SetGlobalTimer("ab_solqmeetcousins","GLOBAL",72000)
                ActionOverride("Slinger",EscapeArea())
                ActionOverride("Shorty",EscapeArea())
                JoinParty()~
                UNSOLVED_JOURNAL @1036
                EXIT
END

IF ~~ THEN BEGIN 14sol
 SAY @1034
 IF ~~ THEN REPLY @1035 GOTO 8sol
END


//Solestia's kickout dialog
BEGIN ab_solP

IF ~Global("ab_soljoined","GLOBAL",1)~ THEN BEGIN p1sol
 SAY @1018 //~Are we to part ways?~
 IF ~~ THEN REPLY @1019 DO ~JoinParty()~ EXIT //~Sorry, it was a mistake. Please help carry our loot...~
 IF ~~ THEN REPLY @1020 DO ~SetGlobal("ab_soljoined","GLOBAL",0)
                            SetGlobal("ab_solCCgo","GLOBAL",1)
                            MoveGlobal("ar0406","Solestia",[1475.1925])~ EXIT //~Yes, we must part ways for a little while. Please go back to the Copper Cornet. If I should need you again, I'll look for you there.~
END

IF ~Global("ab_solCCgo","GLOBAL",1)~ THEN BEGIN p2sol
 SAY @1021 //~You've come back. Do you need my services again?~
 IF ~~ THEN REPLY @1022 DO ~SetGlobal("ab_soljoined","GLOBAL",1)
                            JoinParty()~ EXIT //~Yes.~
 IF ~ReactionLT(LastTalkedToBy(),14)~ THEN REPLY @1023 EXIT //~Not at this time.~
 IF ~ReactionGT(LastTalkedToBy(),8)~ THEN REPLY @1024 GOTO p3sol //~No, I just wanted to make sure that you arrived here safely.~
END

IF ~~ THEN BEGIN p3sol
 SAY @1025 //~I regret that we won't be working together, but I do thank you for your concern. Until next time...~
 IF ~~ THEN EXIT
END