BEGIN ab_solB

IF ~IfValidForPartyDialogue("Solestia")
IfValidForPartyDialogue(Protagonist)
!ActuallyInCombat()
Global("ab_solmeetcousins","GLOBAL",1)
!GlobalTimerNotExpired("ab_solqmeetcousins","GLOBAL")~
THEN BEGIN solpc1
 SAY @1200
 IF ~!AreaCheck("ar0406")~ THEN REPLY @1201 GOTO solpc1-1
 IF ~!AreaCheck("ar0406")~ THEN REPLY @1202 GOTO solpc1-2
 IF ~!AreaCheck("ar0406")~ THEN REPLY @1203 GOTO solpc1-3
 IF ~AreaCheck("ar0406")~ THEN REPLY @1210 EXIT
END

IF ~~ THEN BEGIN solpc1-1
SAY @1204
IF ~~ THEN DO ~SetGlobal("ab_solmeetcousins","GLOBAL",2)
              SetGlobalTimer("ab_solqmeetcuzns2","GLOBAL",7200)~EXIT
END

IF ~~ THEN BEGIN solpc1-2
SAY @1205
IF ~~ THEN DO ~SetGlobal("ab_solmeetcousins","GLOBAL",2)
              SetGlobalTimer("ab_solqmeetcuzns2","GLOBAL",7200)~ EXIT
END
IF ~~ THEN BEGIN solpc1-3
SAY @1206
IF ~~ THEN DO ~SetGlobal("ab_solmeetcousins","GLOBAL",4)
              LeaveParty()
              Wait(1)
              GivePartyAllEquipment()
              EscapeArea()~ EXIT
END

IF ~IfValidForPartyDialogue("Solestia")
IfValidForPartyDialogue(Protagonist)
!ActuallyInCombat()
Global("ab_solmeetcousins","GLOBAL",2)
!GlobalTimerNotExpired("ab_solqmeetcuzns2","GLOBAL")~
THEN BEGIN solpc2
 SAY @1207
 IF ~!AreaCheck("ar0406")~ THEN REPLY @1208 GOTO solpc2-1
 IF ~!AreaCheck("ar0406")~ THEN REPLY @1209 GOTO solpc2-2
 IF ~!AreaCheck("ar0406")~ THEN REPLY @1203 GOTO solpc2-3
 IF ~AreaCheck("ar0406")~ THEN REPLY @1210 EXIT
END

IF ~~ THEN BEGIN solpc2-1
SAY @1204
IF ~~ THEN DO ~SetGlobal("ab_solmeetcousins","GLOBAL",3)
              SetGlobalTimer("ab_solqmeetcuzns3","GLOBAL",7200)~ EXIT
END

IF ~~ THEN BEGIN solpc2-2
SAY @1205
IF ~~ THEN DO ~SetGlobal("ab_solmeetcousins","GLOBAL",3)
              SetGlobalTimer("ab_solqmeetcuzns3","GLOBAL",7200)~EXIT
END

IF ~~ THEN BEGIN solpc2-3
SAY @1206
IF ~~ THEN DO ~SetGlobal("ab_solmeetcousins","GLOBAL",4)
              LeaveParty()
              Wait(1)
              GivePartyAllEquipment()
              EscapeArea()~ EXIT
END

IF ~IfValidForPartyDialogue("Solestia")
IfValidForPartyDialogue(Protagonist)
!ActuallyInCombat()
!AreaCheck("ar0406")
Global("ab_solmeetcousins","GLOBAL",3)
!GlobalTimerNotExpired("ab_solqmeetcuzns3","GLOBAL")~
THEN BEGIN solpc3
 SAY @1211
IF ~~ THEN DO ~SetGlobal("ab_solmeetcousins","GLOBAL",4)
              LeaveParty()
              Wait(1)
              GivePartyAllEquipment()
              EscapeArea()~ EXIT
END