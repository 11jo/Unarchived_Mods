BEGIN ab_solJ

IF ~~ THEN BEGIN 1
 SAY @1111
 IF ~~ THEN REPLY @1112 EXTERN abhalf1 5half1
END

IF ~~ THEN BEGIN 2
 SAY @1124
 IF ~~ THEN EXTERN abhalf2 9half2
END

IF ~~ THEN BEGIN 3
 SAY @1126
 IF ~~ THEN REPLY @1127 
 DO ~SetGlobal("ab_solqmerchant","GLOBAL",3)
     LeaveParty()
     Wait(1)
     GivePartyAllEquipment()
     TakePartyGold(2500)
     EscapeArea()
     ActionOverride("Shorty",EscapeArea())
     ActionOverride("Slinger",EscapeArea())
     EraseJournalEntry(@1119)
     EraseJournalEntry(@1036)
     AddJournalEntry(@1134,QUEST_DONE)~ EXIT
 IF ~~ THEN REPLY @1128
 DO ~SetGlobal("ab_solqmerchant","GLOBAL",3)
     TakePartyGold(2000)
     ActionOverride("Shorty",EscapeArea())
     ActionOverride("Slinger",EscapeArea())
     EraseJournalEntry(@1119)
     EraseJournalEntry(@1036)
     AddJournalEntry(@1135,QUEST_DONE)~ EXIT
 IF ~~ THEN REPLY @1129
 DO ~SetGlobal("ab_solqmerchant","GLOBAL",3)
     LeaveParty()
     Wait(1)
     GivePartyAllEquipment()
     TakePartyGold(2000)
     EscapeArea()
     ActionOverride("Shorty",EscapeArea())
     ActionOverride("Slinger",EscapeArea())
     EraseJournalEntry(@1119)
     EraseJournalEntry(@1036)
     AddJournalEntry(@1136,QUEST_DONE)~ EXIT
END