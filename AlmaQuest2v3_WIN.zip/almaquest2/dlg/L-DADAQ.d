BEGIN ~L-DADAQ~

IF ~NumTimesTalkedTo(0)~ THEN BEGIN welcome
SAY @6
=
@7
=
@8
IF ~~ THEN REPLY @9 GOTO badending
IF ~~ THEN REPLY @10 GOTO informationaboutinformationplusimoen
IF ~~ THEN REPLY @11 GOTO goodending
END

IF ~~ THEN BEGIN badending
SAY @12
IF ~~ THEN DO ~ClearAllActions() 
StartCutSceneMode() 
StartCutScene("L-DACUT")~ EXIT
END

IF ~~ THEN BEGIN informationaboutinformationplusimoen
SAY @13
=
@8
IF ~~ THEN REPLY @9 GOTO badending
IF ~~ THEN REPLY @11 GOTO goodending
END

IF ~~ THEN BEGIN goodending
SAY @14
IF ~~ THEN DO ~EscapeArea()~ EXIT
END