Almateria's Quest 2

	By: Almateria
	Version 3
	02.01.2012
	Contact: Almateria@gery.pl

+++++
ABOUT
+++++

A great adventure unfolds! Kill slimes, murder dragons, loot
ancient shrines, win women over... Or finish the actual
game. What will you choose?

The messenger who starts the quest is in the Government
District, standing near the gate at the bottom of the map.
Only available in Chapter 3.

++++++++
FEATURES
++++++++

- A quest that may actually exist;
- A bad ending.

+++++++++++++++
VERSION HISTORY
+++++++++++++++

11.12.2011
v1
Original release.

15.12.2011
v2
Added a Spanish translation by Lisandro!

02.01.2012
v3
Added a German translation by Clubboth!