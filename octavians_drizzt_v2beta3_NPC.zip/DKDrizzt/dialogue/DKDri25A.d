
BEGIN ~DKDRIZ25~

IF ~Global("DKDrizztErscheinung","GLOBAL",1)~ THEN BEGIN 0 // from:
  SAY @1 
  IF ~~ THEN REPLY @2 DO ~SetGlobal("DKDrizztErscheinung","GLOBAL",2)~ GOTO 1
  IF ~~ THEN REPLY @3 DO ~SetGlobal("DKDrizztErscheinung","GLOBAL",2)~ GOTO 4
END

IF ~~ THEN BEGIN 1 // from: 0.1 0.0
  SAY @4 
  IF ~~ THEN GOTO 3
END

IF ~~ THEN BEGIN 2 // from: 1.0
  SAY @5 
  IF ~~ THEN GOTO 3
END

IF ~~ THEN BEGIN 3 // from: 2.0
  SAY @6 
  IF ~~ THEN REPLY @7 DO ~JoinParty()~ EXIT
  IF ~~ THEN REPLY @8 GOTO 4
  IF ~~ THEN REPLY @9 GOTO 5
END

IF ~~ THEN BEGIN 4 // from: 3.1 0.2
  SAY @10 
  IF ~~ THEN REPLY @11 DO ~JoinParty()~ EXIT
  IF ~~ THEN REPLY @12 GOTO 5
END

IF ~~ THEN BEGIN 5 // from: 4.1 3.2
  SAY @13 
  IF ~~ THEN DO ~MoveToPointNoInterrupt([1720.1530])
Face(0)~ EXIT
END

IF ~Global("DKDrizztErscheinung","GLOBAL",2)~ THEN BEGIN 6 // from:
  SAY @14 
  IF ~~ THEN REPLY @15 DO ~JoinParty()~ EXIT
  IF ~~ THEN REPLY @16 GOTO 7
END

IF ~~ THEN BEGIN 7 // from: 6.1
  SAY @17 
  IF ~~ THEN EXIT
END

