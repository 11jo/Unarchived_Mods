BEGIN ~DKGUENJ~

IF ~True()~ THEN BEGIN HalloGuen1
  SAY @0
  IF ~~ THEN REPLY @1 DO ~SetGlobal("DKBewegungGuen","GLOBAL",0) SetGlobal("DKAngriffGuenMagier","GLOBAL",0)~ EXIT
  IF ~~ THEN REPLY @2 DO ~SetGlobal("DKBewegungGuen","GLOBAL",1) SetGlobal("DKAngriffGuenMagier","GLOBAL",0)~ EXIT
  IF ~~ THEN REPLY @3 DO ~SetGlobal("DKAngriffGuenMagier","GLOBAL",1) SetGlobal("DKBewegungGuen","GLOBAL",0)~ EXIT
  IF ~~ THEN REPLY @4 DO ~MoveToObject("DKDrizzt")~ EXIT	
END


APPEND JANJ
  IF ~~ THEN BEGIN DK_166
    SAY @7
    IF ~!IsValidForPartyDialog("Jaheira")
  !IsValidForPartyDialog("Keldorn")
  !IsValidForPartyDialog("Viconia")~ THEN EXTERN ~C6BRUEN1~ DK_14
    IF ~IsValidForPartyDialog("Jaheira")~ THEN EXTERN ~JAHEIRAJ~ DK_475
    IF ~!IsValidForPartyDialog("Jaheira")
  IsValidForPartyDialog("Keldorn")~ THEN EXTERN ~KELDORJ~ DK_206
    IF ~!IsValidForPartyDialog("Jaheira")
  !IsValidForPartyDialog("Keldorn")
  IsValidForPartyDialog("Viconia")~ THEN EXTERN ~VICONIJ~ DK_150
  END
END

APPEND JAHEIRAJ
  IF ~~ THEN BEGIN DK_475
    SAY @8
    IF ~!IsValidForPartyDialog("Keldorn")
  !IsValidForPartyDialog("Viconia")~ THEN EXTERN ~C6BRUEN1~ DK_14
    IF ~IsValidForPartyDialog("Keldorn")~ THEN EXTERN ~KELDORJ~ DK_206
    IF ~!IsValidForPartyDialog("Keldorn")
  IsValidForPartyDialog("Viconia")~ THEN EXTERN ~VICONIJ~ DK_150
  END
END

APPEND KELDORJ
  IF ~~ THEN BEGIN DK_206
    SAY @9
    IF ~!IsValidForPartyDialog("Viconia")~ THEN EXTERN ~C6BRUEN1~ DK_14
    IF ~IsValidForPartyDialog("Viconia")~ THEN EXTERN ~VICONIJ~ DK_150
  END
END

APPEND VICONIJ
  IF ~~ THEN BEGIN DK_150
    SAY @10
    IF ~~ THEN EXTERN ~C6BRUEN1~ DK_14
  END
END


APPEND ~C6BRUEN1~
  IF ~~ THEN BEGIN DK_14
    SAY @11
    IF ~~ THEN EXTERN ~C6Wulf1~ DK_4
  END
END

APPEND ~C6WULF1~
  IF ~~ THEN BEGIN DK_4
    SAY @12
    IF ~~ THEN EXTERN ~C6Regis1~ DK_4
  END
END

APPEND ~C6REGIS1~
  IF ~~ THEN BEGIN DK_4
    SAY @13
    IF ~~ THEN EXTERN ~C6Catti1~ DK_4
  END
END  	

APPEND ~C6CATTI1~
  IF ~~ THEN BEGIN DK_4
    SAY @14
    IF ~~ THEN EXTERN ~C6DRIZZ1~ DK_59
  END
END
  
INTERJECT_COPY_TRANS BODHIAMB 0 DKDrizztBodhi1
  == DKDrizzJ   IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN 
    @15
  == BODHIAMB   IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN 
    @16
  == DKDrizzJ   IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN 
    @17
END  


I_C_T ARAN 77 DKDrizztAran1
  == DKDrizzJ    IF ~Global("DKDrizztKommu","GLOBAL",1) InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN 
    @18 
  == ARAN        IF ~Global("DKDrizztKommu","GLOBAL",1) InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN
    @19
  == DKDrizzJ    IF ~Global("DKDrizztKommu","GLOBAL",1) InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN
    @20
  == ARAN        IF ~Global("DKDrizztKommu","GLOBAL",1) InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN  
    @21
END

INTERJECT_COPY_TRANS ARAN 77 DKDrizztAran2
  == DKDrizzJ    IF ~Global("DKDrizztKommu","GLOBAL",2) InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN
    @22
END

INTERJECT_COPY_TRANS ARAN 77 DKDrizztAran3
  == DKDrizzJ    IF ~Global("DKDrizztKommu","GLOBAL",3) InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN
     @23 
END

INTERJECT_COPY_TRANS ARAN 77 DKDrizztAran4
  == DKDrizzJ    IF ~Global("DKDrizztKommu","GLOBAL",4) InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN
     @24 
END

INTERJECT_COPY_TRANS TCADRIL 1 DKDrizztCa1
  == DKDrizzJ    IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN
     @25
  == TCADRIL      IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN
     @26
END


INTERJECT_COPY_TRANS HPRELATE 45 DKDrizztPr1
  == DKDrizzJ    IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID) Global("DKDrizztKommu","GLOBAL",1) 
~ THEN
     @27
  == HPRELATE    IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID) Global("DKDrizztKommu","GLOBAL",1) 
~ THEN
     @28
END

INTERJECT_COPY_TRANS HPRELATE 45 DKDrizztPr2
  == DKDrizzJ    IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID) Global("DKDrizztKommu","GLOBAL",2) 
~ THEN
     @29
  == HPRELATE    IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID) Global("DKDrizztKommu","GLOBAL",2) 
~ THEN
     @30
END

INTERJECT_COPY_TRANS HPRELATE 45 DKDrizztPr3
  == DKDrizzJ    IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID) Global("DKDrizztKommu","GLOBAL",3) 
~ THEN
     @31
  == HPRELATE    IF~ InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID) Global("DKDrizztKommu","GLOBAL",3) 
~ THEN
     @32
END

INTERJECT_COPY_TRANS HPRELATE 45 DKDrizztPr4
  == DKDrizzJ    IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID) Global("DKDrizztKommu","GLOBAL",4) 
~ THEN
     @33
  == HPRELATE    IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID) Global("DKDrizztKommu","GLOBAL",4) 
~ THEN
     @34
END

INTERJECT_COPY_TRANS C6Bodhi 0 DKDrizztc6bo
  == DKDrizzJ     IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)
~ THEN
     @35
  == C6BODHI      IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)
~ THEN
     @36
END

INTERJECT_COPY_TRANS C6Elhan2 64 DKDrizztElhan1
  == C6Elhan2   IF~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)
~ THEN
    @37
  == DKDrizzJ    IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)
~ THEN
     @38
  == C6Elhan2    IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)
~ THEN
     @39
END

INTERJECT_COPY_TRANS Suraam 0 DKDrizztSuraam1
  == DKDrizzJ  IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)
~ THEN
     @40
  == Suraam    IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)
~ THEN
     @41
END

INTERJECT_COPY_TRANS Sudemin 11 DKDrizztSudemin1
  == DKDrizzJ  IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)
~ THEN
     @42
  == Sudemin   IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)
~ THEN
     @43
 == DKDrizzJ  IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)
~ THEN
     @44
== Sudemin   IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)
~ THEN
     @45
END 

INTERJECT_COPY_TRANS Hellfear 14 DKDrizztNymphen
  == DKDrizzJ IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)
~ THEN
     @46
END

EXTEND_BOTTOM PLAYER1 33 // tree of life gut check 
  IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID) Global("DKDrizztLebensbaum","GLOBAL",0)~ 
    THEN DO ~SetGlobal("DKDrizztLebensbaum","GLOBAL",1)~ EXTERN PLAYER1 Lebensbaum
END

APPEND PLAYER1 
  IF ~~ THEN BEGIN Lebensbaum
    SAY @47
    IF ~~ THEN REPLY @48 EXTERN DKDrizzJ Leben_1
    IF ~~ THEN REPLY @49 EXTERN DKDrizzJ Leben_2
  END
END

EXTEND_BOTTOM PLAYER1 25
  IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID) Global("DKDrizztHoelle","GLOBAL",0)~ 
    THEN DO ~SetGlobal("DKDrizztHoelle","GLOBAL",1)~ EXTERN DKDrizzJ Hoelle
END

ADD_STATE_TRIGGER C6Harp 12 ~OR(3) 
!InParty("DKDrizzt") 
!InMyArea("DKDrizzt") StateCheck("DKDrizzt",CD_STATE_NOTVALID)~

ADD_STATE_TRIGGER C6Harp 0 ~OR(3) 
!InParty("DKDrizzt") 
!InMyArea("DKDrizzt") StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ 

ADD_STATE_TRIGGER Obsgol01 3 ~!PartyHasItem("DKGOLT")~

APPEND OBSGOL01
  IF ~~ THEN BEGIN DK_9
    SAY @50
    IF ~~ THEN DO ~SetGlobal("DKGolemVerwandlung","GLOBAL",1)~ EXIT
  END

  IF ~PartyHasItem("DKGOLT")
Global("PCSphere","GLOBAL",0)
Dead("obsdem03")
NumTimesTalkedToGT(0)~ THEN BEGIN DK_10 
  SAY @51 
  IF ~~ THEN REPLY @52 EXIT
  IF ~~ THEN REPLY @53 GOTO DK_9
  END
END

EXTEND_BOTTOM OBSGOL01 4
  IF ~PartyHasItem("DKGOLT")~
    THEN REPLY @54 GOTO DK_9
END

I_C_T HellJon 7 DKHellJon
== DKDrizzJ IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN @188
END

I_C_T HellJon 8 DKHellJon
== DKDrizzJ IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN @188
END

I_C_T HellJon 9 DKHellJon
== DKDrizzJ IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN @188
END

I_C_T HellJon 10 DKHellJon
== DKDrizzJ IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN @188
END




A_T_T C6DRIZZ1 36 ~False()~

EXTEND_BOTTOM C6DRIZZ1 36
IF ~~ THEN REPLY #53419 + DK_37
END

APPEND C6DRIZZ1

IF ~~ THEN BEGIN DK_37 
  SAY @124 
+ ~!IsValidForPartyDialog("Jan")
!IsValidForPartyDialog("Jaheira")
!IsValidForPartyDialog("Keldorn")
!IsValidForPartyDialog("Viconia")~ + @199 UNSOLVED_JOURNAL @125  EXTERN ~C6BRUEN1~ DK_14
+ ~IsValidForPartyDialog("Jan")~ + @199 UNSOLVED_JOURNAL @125 EXTERN ~JANJ~ DK_166
+ ~!IsValidForPartyDialog("Jan")
IsValidForPartyDialog("Jaheira")~ + @199 UNSOLVED_JOURNAL @125 EXTERN ~JAHEIRAJ~ DK_475
+ ~!IsValidForPartyDialog("Jan")
!IsValidForPartyDialog("Jaheira")
IsValidForPartyDialog("Keldorn")~ + @199 UNSOLVED_JOURNAL @125 EXTERN ~KELDORJ~ DK_206
+ ~!IsValidForPartyDialog("Jan")
!IsValidForPartyDialog("Jaheira")
!IsValidForPartyDialog("Keldorn")
IsValidForPartyDialog("Viconia")~ + @199 UNSOLVED_JOURNAL @125 EXTERN ~VICONIJ~ DK_150
++ @200 + 37
END



IF ~~ THEN BEGIN DK_59
  SAY @164
  IF ~~ THEN GOTO DK_60
END

IF ~~ THEN BEGIN DK_60
  SAY @165
  IF ~~ THEN DO ~Shout(81)
JoinParty()~ EXIT
END

IF ~~ THEN BEGIN DK_61
  SAY @166
 IF ~~ THEN EXIT
END

IF ~~ THEN BEGIN DK_62
  SAY @167
  IF ~~ THEN EXTERN ~BODHIAMB~ 5
END

END

BEGIN DKDrizzJ

IF ~ReputationLT(Player1,10)~ THEN BEGIN Schlecht
  SAY @168 
  IF ~~ THEN DO ~LeaveParty() EscapeArea()~ EXIT
END

IF ~Global("DKDrizztsauer","GLOBAL",1)~ THEN BEGIN Verlassen
  SAY @169
  IF ~~ THEN DO ~LeaveParty() EscapeArea()~ EXIT
END

IF ~Global("ShadowFightBodhi","GLOBAL",1) Global("OrderFightBodhi","GLOBAL",1) Global("DKDrizztSchattenLicht","LOCALS",0)~  THEN BEGIN Wunder	
   SAY @170
   IF ~~ THEN REPLY @171 DO ~SetGlobal("DKDrizztSchattenLicht","LOCALS",1)~ GOTO Ok
   IF ~~ THEN REPLY @172 DO ~SetGlobal("DKDrizztSchattenLicht","LOCALS",1)~ GOTO Ok
   IF ~~ THEN REPLY @173 DO ~SetGlobal("DKDrizztSchattenLicht","LOCALS",1)~ GOTO Verlassen
END

IF ~~ THEN BEGIN Ok
   SAY @174
   IF ~~ THEN EXIT
END

IF ~~ THEN BEGIN Ok2
   SAY @175
   IF ~~ THEN EXIT
END


IF ~Global("DKDeathOfBodhi","LOCALS",0) Global("BodhiDead","GLOBAL",1)~ THEN BEGIN Drizztaufbruch
   SAY @176
   IF ~~ THEN REPLY @177 DO ~SetGlobal("DKDeathOfBodhi","LOCALS",1)~ GOTO Ok2
   IF ~~ THEN REPLY @178 DO ~SetGlobal("DKDeathOfBodhi","LOCALS",1)~ GOTO Verlassen2
END

IF ~~ THEN BEGIN Verlassen2
   SAY @179
   IF ~~ THEN DO ~LeaveParty() EscapeArea()~ EXIT
END



IF ~~ THEN BEGIN Leben_1
  SAY @181
  COPY_TRANS PLAYER1 33
END
IF ~~ THEN BEGIN Leben_2
  SAY @182  
  COPY_TRANS PLAYER1 33
END

IF ~Dead("suearth") Global("DKDrizztParasit","LOCALS",0)~ THEN BEGIN DrizztPara
  SAY @183 
  IF ~~ THEN DO ~SetGlobal("DKDrizztParasit","LOCALS",1)~ EXIT
END
	
IF ~~ THEN BEGIN Hoelle
  SAY @184
  COPY_TRANS PLAYER1 25
END


IF ~Global("BhaalDoor","GLOBAL",1) Global("DKHoelle_Ratschlag","LOCALS",0)~ THEN BEGIN Hoelle_Ratschlag
  SAY  @185
  IF ~~ THEN DO ~SetGlobal("DKHoelle_Ratschlag","LOCALS",1)~ EXIT
END

IF ~Dead("Hellgen") PartyHasItem("MiscBC") Global("DKHoelle_boese_Waffe","LOCALS",0)~ THEN BEGIN Hoelle_boese_Waffe
  SAY @186
  IF ~~ THEN DO ~SetGlobal("DKHoelle_boese_Waffe","LOCALS",1)~ EXIT
END

IF ~Global("Player1Selfish","GLOBAL",1) Global("DKHoelle_Wahr","LOCALS",0)~ THEN BEGIN Hoelle_Richtig
  SAY @187
  IF ~~ THEN DO ~SetGlobal("DKHoelle_Wahr","LOCALS",1)~ EXIT
END

IF ~~ THEN BEGIN Undank
  SAY @189
  IF ~~ THEN DO ~LeaveParty() 
SetGlobal("DKArtDrizKampf1","GLOBAL",1) 
ENEMY()
~ EXIT
END

IF ~Global("DKCadderlyDrizzt2","GLOBAL",1)~ THEN BEGIN CaddPlayerfragen
  SAY @190
  IF ~CheckStatGT(Player1,14,INT)~ THEN REPLY @191 DO ~SetGlobal("DKCadderlyDrizzt2","GLOBAL",2)~ GOTO DrizztWanderer
  IF ~CheckStatLT(Player1,15,INT)~ THEN REPLY @192 DO ~SetGlobal("DKCadderlyDrizzt2","GLOBAL",2)~ GOTO DrizztRettungDeud  
END

IF ~~ THEN BEGIN DrizztWanderer
  SAY @193
  IF ~~ THEN DO ~SetGlobal("DKRobiPartyzurueck","GLOBAL",1) SetGlobal("DKGewusst","GLOBAL",1)~ EXIT
END

IF ~~ THEN BEGIN DrizztRettungDeud 
  SAY @194
  IF ~~ THEN DO ~SetGlobal("DKRobiPartyzurueck","GLOBAL",1)~ EXIT
END

CHAIN
IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID) Global("DKDrizztMalch1","GLOBAL",0)~ THEN C6Harp HarpellDrizzt1
@5
== DKDrizzJ @180
== C6Harp @6 DO ~SetGlobal("DKDrizztMalch1","GLOBAL",1) ReallyForceSpell(Myself,DRYAD_TELEPORT)~ 
EXIT
  
BEGIN DKDRIZZP 

IF ~Global("DKDrizztsauer","GLOBAL",1)~ THEN BEGIN Verlassen
  SAY @195
  IF ~~ THEN DO ~EscapeArea()~ EXIT
END

IF ~Global("DKDrizztJoined","LOCALS",0)~ THEN BEGIN KickOut
  SAY @196
  IF ~~ THEN REPLY @197 DO ~JoinParty()~ EXIT
  IF ~~ THEN REPLY @198 DO ~SetGlobal("DKDrizztJoined","LOCALS",1)
EscapeArea() ~ EXIT
END


