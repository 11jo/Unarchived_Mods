BEGIN ~DKBDRIZZ~

APPEND ~DKBDRIZZ~
  IF ~Global("DKDrizztBruenorDialog","LOCALS",0)
      See("C6Bruen")
      !StateCheck("C6Bruen",STATE_SLEEPING)~ THEN BEGIN DrizztAbschied
    SAY @1
    IF ~~ THEN DO ~SetGlobal("DKDrizzBruenorDialog","LOCALS",1)~ 
      EXTERN C6BRUEN1 DrizztDialog
  END                                   // ENDE VON DrizztAbschied

  // Noch sind wir im Block
  IF ~~ THEN BEGIN DrizztEnde
    SAY @2
    IF ~~ THEN EXIT
  END                            // ENde von Drizz ENde
END

CHAIN C6BRUEN1 DrizztDialog
  @3
END DKBDRIZZ DrizztEnde 
