EXTEND_BOTTOM Sarvolo 9
  IF ~InParty("DKDrizzt")~ 
    THEN REPLY @1 GOTO VoloDrizzt1
  END

APPEND ~Sarvolo~ 
  IF ~~ THEN BEGIN VoloDrizzt1
    SAY @2  
    IF ~InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN  EXTERN DKDRI25J VoloG
    IF ~OR(2) !InMyArea("DKDrizzt") StateCheck("DKDrizzt",CD_STATE_NOTVALID)~  THEN + 9
  END
END

APPEND ~Vicon25j~
  IF ~~ THEN BEGIN ViciDrizztnett
    SAY @3
    IF ~~ THEN EXIT
   END
END
	
EXTEND_BOTTOM FATESP 6
  IF ~Global("DKDrizztErscheinung","GLOBAL",0)
      !InParty("DKDrizzt") !Dead("DKDrizzt")~THEN REPLY @4 
   DO ~SetGlobal("DKDrizztErscheinung","GLOBAL",1)~ GOTO 8
END

EXTEND_BOTTOM Vicon25j 33
  IF ~InParty("DKDrizzt") InMyArea("DKDrizzt")  !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN EXTERN DKDRI25J ViconiaGespraech 
  END

// Dialoge in ToB durch Interject ++++NEU++++ - Interject dialogues in ToB
INTERJECT_COPY_TRANS SARELF05 0 DKDrizztElf // Die Elfen und Zwerge in Saradush  in einer Kneipe
  == DKDRI25J   IF ~InParty("DKDrizzt") InMyArea("DKDrizzt")  !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN 
    @5
  == SARELF05   IF ~InParty("DKDrizzt") InMyArea("DKDrizzt")  !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN 
    @6
  == DKDRI25J   IF ~InParty("DKDrizzt") InMyArea("DKDrizzt")  !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN 
    @7
  == SARELF06   IF ~InParty("DKDrizzt") InMyArea("DKDrizzt")  !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN 
    @8 
  == DKDRI25J   IF ~InParty("DKDrizzt") InMyArea("DKDrizzt")  !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN 
    @9
  == SARDW04   IF ~InParty("DKDrizzt") InMyArea("DKDrizzt")  !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN 
    @10 
  == SARELF05   IF ~InParty("DKDrizzt") InMyArea("DKDrizzt")  !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN 
    @11 DO ~ActionOverride("SARELF06",EscapeArea())
ActionOverride("SARDW04",EscapeArea())
ActionOverride("SARDW05",EscapeArea())
ActionOverride("SARELF05",EscapeArea())~
END  

INTERJECT_COPY_TRANS SARVIE01 6 DKDrizztViekangHilfe // Hilfe f r Viekang in  Saradush 
  == DKDRI25J   IF ~InParty("DKDrizzt") InMyArea("DKDrizzt")  !StateCheck("DKDrizzt",CD_STATE_NOTVALID) CheckStatLT(Player1,17,INT)~ THEN 
    @12
  == SARVIE01   IF ~InParty("DKDrizzt") InMyArea("DKDrizzt")  !StateCheck("DKDrizzt",CD_STATE_NOTVALID) CheckStatLT(Player1,17,INT)~ THEN 
    @13
  == DKDRI25J   IF ~InParty("DKDrizzt") InMyArea("DKDrizzt")  !StateCheck("DKDrizzt",CD_STATE_NOTVALID) CheckStatLT(Player1,17,INT)~ THEN 
    @14
  == SARVIE01   IF ~InParty("DKDrizzt") InMyArea("DKDrizzt")  !StateCheck("DKDrizzt",CD_STATE_NOTVALID) CheckStatLT(Player1,17,INT)~ THEN 
    @15
END


I_C_T SARBAR01 7 DKMeinungMellisan
== DKDRI25J IF ~InParty("DKDrizzt") InMyArea("DKDrizzt")  !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN @20
END

I_C_T SARBAR01 14 DKMeinungGeld
== DKDRI25J IF ~InParty("DKDrizzt") InMyArea("DKDrizzt")  !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN @21
END

I_C_T SARPROVF 0 DKDrizztHure1
== DKDRI25J IF ~InParty("DKDrizzt") InMyArea("DKDrizzt")  !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN @22
END

 
BEGIN DKDRI25J

IF ~ReputationLT(Player1,10)~ THEN Schlecht
  SAY @16
  IF ~~ THEN DO ~LeaveParty() EscapeArea()~ EXIT
END

IF ~~ THEN BEGIN VoloG
  SAY @17
  IF ~~ THEN EXTERN ~Sarvolo~ 9
END

IF ~~ THEN BEGIN ViconiaGespraech 
   SAY @18 
   IF ~~ THEN EXTERN ~Sarvolo~ 9
END

IF ~Global("DKDrizztViciNett","LOCALS",1)~ THEN DrizztViciNett
   SAY @19
   IF ~~ THEN DO ~SetGlobal("DKDrizztViciNett","LOCALS",2)~ EXTERN ~Vicon25j~ ViciDrizztnett
END
 

BEGIN DKDRI25P 

IF ~Global("DKDrizztsauer","GLOBAL",1)~ THEN BEGIN Verlassen
  SAY @23
  IF ~~ THEN DO ~EscapeArea()~ EXIT
END

IF ~Global("DKDrizztJoined25","LOCALS",0)~ THEN BEGIN KickOut
  SAY @24
  IF ~~ THEN REPLY @25 DO ~JoinParty()~ EXIT
  IF ~~ THEN REPLY @26 DO ~SetGlobal("DKDrizztJoined25","LOCALS",1)
EscapeArea() ~ EXIT
END