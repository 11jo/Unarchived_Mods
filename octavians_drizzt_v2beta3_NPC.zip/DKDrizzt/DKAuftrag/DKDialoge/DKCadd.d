BEGIN DKCADD

IF ~Global("DKCadderlyDrizzt","GLOBAL",0) NumTimesTalkedTo(0)~ THEN BEGIN Erstaunt
  SAY @1
  IF ~~ THEN EXTERN DKDrizzJ CaddDrizzt1
END

IF ~Global("DKCadderlyDrizzt","GLOBAL",1) Global("DKCadderlyDrizzt2","GLOBAL",0)~ THEN BEGIN Erstaunt2
  SAY @3
  IF ~~ THEN EXTERN DKDrizzJ CaddDrizzt2
END


CHAIN DKDrizzJ CaddDrizzt1
   @4
== DKCADD
     @5
DO ~ClearAllActions()
StartCutSceneMode()
FadeToColor([20.0],0)
Wait(1)
SetGlobal("DKAurilAngriffBeginn","GLOBAL",1)
SetGlobal("DKCadderlyDrizzt","GLOBAL",1)
StartCutScene("DKMOVIED")~ EXIT


CHAIN DKDrizzJ CaddDrizzt2
   @6
== DKCADD
   @7
== DKDrizzJ
   @8
== DKCADD
   @9
== DKDrizzJ
   @10
== DKCADD
   @11
DO ~SetGlobal("DKCadderlyDrizzt2","GLOBAL",1)~ 
EXIT

