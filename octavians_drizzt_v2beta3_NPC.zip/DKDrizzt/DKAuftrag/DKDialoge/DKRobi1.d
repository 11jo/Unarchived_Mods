BEGIN DKRobi 

IF ~Global("DKRobiPartyzurueck","GLOBAL",1) Global("DKRobiDrizztzurueck","LOCALS",0)~  THEN BEGIN NachDocks
  SAY @1
  IF ~~ THEN EXTERN  ~DKDrizzJ~ DrizztRobi3

END

IF ~InParty("DKDrizzt")
      See("DKDrizzt")
NumTimesTalkedTo(0)~ THEN BEGIN Hilfe
  SAY @2
  IF ~~ THEN EXTERN  ~DKDrizzJ~ DrizztRobi1
END

CHAIN DKDrizzJ DrizztRobi3
   @3
== DKRobi 
    @4
DO ~ClearAllActions()
StartCutSceneMode()
StartCutScene("DKCUTB")~EXIT


CHAIN DKDrizzJ DrizztRobi1
   @5
== DKRobi 
   @6
DO ~ClearAllActions()
StartCutSceneMode()
FadeToColor([20.0],0)
Wait(1)
StartCutScene("DKMOVIEA")~ EXIT


APPEND ~DKDrizzJ~
IF ~Global("DKFilm","GLOBAL",1)
	Global("DKDrizztantwortet","LOCALS",0)~ THEN BEGIN DrizztRobiEntgegnung
  SAY @7
  IF ~~ THEN REPLY @8 DO ~SetGlobal("DKDrizztantwortet","LOCALS",1)~ GOTO CharnameDrizztdabei
  IF ~~ THEN REPLY @9 DO ~SetGlobal("DKDrizztantwortet","LOCALS",1)~ GOTO PCDrizztreden1
  IF ~~ THEN REPLY @10 DO ~SetGlobal("DKDrizztsauer","GLOBAL",1) SetGlobal("DKDrizztantwortet","LOCALS",1)~ GOTO Drizztgeht
 END

IF ~~ THEN BEGIN PCDrizztreden1
  SAY  @11 
  IF ~~ THEN EXTERN DKRobi DrizztRobi2
END

IF ~~ THEN BEGIN CharnameDrizztdabei
  SAY @12 
  IF ~~ THEN EXTERN DKRobi DrizztRobi2
END

IF ~~ THEN BEGIN Drizztgeht
  SAY @13
  IF ~~ THEN DO ~LeaveParty() EscapeArea()~ EXIT
END
END

CHAIN DKRobi DrizztRobi2
  @14
== DKDrizzJ
  @15
== DKRobi
  @16
DO ~Wait(1)
StartCutScene("DKCutA")~EXIT