BEGIN DKAuril

IF ~See([PC]) !See(Player1) Global("DKLetzterTrunpf","LOCALS",0)~ THEN BEGIN HolHC
   SAY @1 
   IF ~~ THEN DO ~ClearAllActions()
StartCutSceneMode()
StartCutScene("DKCauril")~ EXIT
END

IF ~Global("DKAurilMove","LOCALS",1)~ THEN BEGIN AurilGeschafft
  SAY @2
  IF ~Global("DKAurilgeschwaecht","GLOBAL",1)~ THEN DO ~SetGlobal("DKAurilMove","LOCALS",2)~ 
      REPLY @3 GOTO AurilVerdammt
  IF ~Global("DKAurilgeschwaecht","GLOBAL",2)~ THEN DO ~SetGlobal("DKAurilMove","LOCALS",2)~ 
      REPLY @3 GOTO AurilVerdammt2
  IF ~Global("DKAurilgeschwaecht","GLOBAL",0)~ THEN DO ~SetGlobal("DKAurilMove","LOCALS",2)~ 
      REPLY @4 GOTO AurilVerdammt3
END

IF ~See([PC]) See(Player1) Global("DKLetzterTrunpf","LOCALS",0)~ THEN BEGIN AurilEinleitung
  SAY @2
  IF ~Global("DKAurilgeschwaecht","GLOBAL",1)~ THEN REPLY @3 GOTO AurilVerdammt
  IF ~Global("DKAurilgeschwaecht","GLOBAL",2)~ THEN REPLY @3 GOTO AurilVerdammt2
  IF ~Global("DKAurilgeschwaecht","GLOBAL",0)~ THEN REPLY @4 GOTO AurilVerdammt3
END
 
IF ~~ THEN BEGIN AurilVerdammt
  SAY @5
  IF ~~ THEN DO ~CreateCreatureObjectDoor("DKEISRI1","DKAuril",0,0,0) // Cambion
CreateCreatureObjectDoor("DKEISGOL","DKAuril",0,0,0) // Cambion
CreateCreatureObjectDoor("DKEISGO2","DKAuril",0,0,0) 
Enemy()~ EXIT
END

IF ~~ THEN BEGIN AurilVerdammt2
  SAY @5
  IF ~~ THEN DO ~CreateCreatureObjectDoor("DKEISRI1","DKAuril",0,0,0) // Cambion
CreateCreatureObjectDoor("DKEISGO2","DKAuril",0,0,0) 
Enemy()~ EXIT
END

IF ~~ THEN BEGIN AurilVerdammt3
  SAY @6
  IF ~~ THEN DO ~CreateCreatureObjectDoor("DKEISRI1","DKAuril",0,0,0) // Cambion
CreateCreatureObjectDoor("DKEISRI2","DKAuril",0,0,0) // Cambion
CreateCreatureObjectDoor("DKEISGO2","DKAuril",0,0,0) 
CreateCreatureObjectDoor("DKEISGOL","DKAuril",0,0,0) 
Enemy()~ EXIT
END

IF ~Global("DKLetzterTrunpf","LOCALS",1)~ THEN BEGIN DKAurilhilft
  SAY @7
  IF ~~ THEN DO ~ClearAllActions() StartCutSceneMode() CreateCreatureObjectDoor("DKEISDEU","DKAuril",0,0,0) Wait(3) EndCutSceneMode()~ EXIT
END
 
