APPEND DKDrizzJ
IF ~~ THEN BEGIN DeudDrizztDank
   SAY @1
   IF ~~ THEN EXTERN DKEisd DeudDrizztDank2
END
END

BEGIN DKEisd

IF ~NumTimesTalkedTo(0)~ THEN BEGIN DeudEinleitung
   SAY @2
   IF ~~ THEN DO ~ActionOverride("DKAuril",DestroyItem("MINHP1")) Wait(1) Enemy()~ EXIT
END
 
IF ~Global("DKEisdeusprechen","GLOBAL",1)~ THEN BEGIN Deudzuruck
  SAY @3
  IF ~~ THEN REPLY @4 DO ~AddExperienceParty(30000) SetGlobal("DKEisdeusprechen","AR0300",2)~ GOTO Deudzuruck1                
END

IF ~~  THEN BEGIN Deudzuruck1
  SAY @5
  IF ~InParty("DKDrizzt") InMyArea("DKDrizzt") !StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN EXTERN DKDrizzJ DeudDrizztDank
  IF ~OR(3) !InParty("DKDrizzt") !InMyArea("DKDrizzt") StateCheck("DKDrizzt",CD_STATE_NOTVALID)~ THEN GOTO DeudDrizztDank2
END

IF ~~ THEN BEGIN DeudDrizztDank2
  SAY @6
  IF ~~ THEN DO ~FadeToColor([20.0],0) Wait(1) DestroySelf() SetGlobal("DKAurilAngriffBeginn","GLOBAL",2) FadeFromColor([20.0],0)~ EXIT
END
 