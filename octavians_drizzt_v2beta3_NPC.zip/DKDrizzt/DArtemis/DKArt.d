BEGIN DKARTEMI 


IF ~Global("DKArtDrizKom1","LOCALS",1)~ THEN BEGIN Wahl
  SAY @1
  IF ~~ THEN REPLY @2 DO ~SetGlobal("DKArtDrizKom1","LOCALS",2)~ GOTO Kampf
  IF ~~ THEN REPLY @3 DO ~SetGlobal("DKArtDrizKom1","LOCALS",2)~ GOTO Kampf2
END

IF ~~ THEN BEGIN Kampf
  SAY @4 
  IF ~Difficulty(EASIEST)~ THEN DO ~Enemy()
CreateCreatureObject("DKAHelfe",Myself,0,0,0)
~ EXIT
  IF ~Difficulty(EASY)~ THEN DO ~Enemy()
CreateCreatureObject("DKAHelfe",Myself,0,0,0) 
CreateCreatureObject("DKAHelfe",Myself,0,0,0)
~ EXIT
  IF ~Difficulty(NORMAL)~ THEN DO ~Enemy()
CreateCreatureObject("DKAHelfe",Myself,0,0,0)
CreateCreatureObject("DKAHelfe",Myself,0,0,0)
CreateCreatureObject("DKAHelfe",Myself,0,0,0)
~ EXIT
  IF ~DifficultyGT(NORMAL)~ THEN DO ~Enemy()
CreateCreatureObject("DKAHelfe",Myself,0,0,0)
CreateCreatureObject("DKAHelfe",Myself,0,0,0)
CreateCreatureObject("DKAHelfe",Myself,0,0,0)
CreateCreatureObject("DKAHelfe",Myself,0,0,0)
CreateCreatureObject("DKAHelf2",Myself,0,0,0)
ActionOverride("DKArt1",MoveToObject("DKDrizzt"))
~ EXIT
END


IF ~~ THEN BEGIN Kampf2
  SAY @5
  IF ~~ THEN EXTERN ~DKDrizzJ~ 19
END
 
IF ~Dead("DKDrizzt")~ THEN BEGIN Gewonnen
  SAY @6
  IF ~~  THEN DO ~SetGlobal("DKArtSieg","LOCALS",1)~ EXIT
END


APPEND ~DKARTEMI~
  IF ~Global("DKArtDrizKom1","LOCALS",0)
      InParty("DKDrizzt")
      See("DKDrizzt")
      !StateCheck("DKDrizzt",STATE_SLEEPING)~ THEN BEGIN Kommuchain
  SAY @7
  IF ~~ THEN EXTERN DKDrizzJ ArtDriz1
  END

  IF ~~ THEN BEGIN ArtemisAus
    SAY @8
    IF ~~ THEN DO ~SetGlobal("DKArtDrizKom1","LOCALS",1)~ EXIT
  END
END
CHAIN DKDrizzJ ArtDriz1
  @9  
  == DKARTEMI
  @10
  == DKDrizzJ
  @11
  == DKARTEMI
  @12
  == DKDrizzJ
  @13
  == DKARTEMI
  @14 DO ~SetGlobal("DKArtemisFrage1","GLOBAL",1)~
END DKARTEMI ArtemisAus

